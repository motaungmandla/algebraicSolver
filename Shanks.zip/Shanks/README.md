"algebraiSlover"
"algebraicSolver"
